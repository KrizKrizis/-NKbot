# lottery/keyboards/lottery.py
# Клавиатуры для лотереи.

from vkbottle import Keyboard, KeyboardButtonColor, Text


def get_lottery_main_keyboard(can_buy: bool) -> str:
    """Главное меню лотереи. Кнопка всегда «Купить билет», цвет зависит от доступности."""
    keyboard = Keyboard(one_time=False, inline=True)
    if can_buy:
        keyboard.add(Text("Купить билет", payload={"cmd": "lottery_buy_ticket"}), color=KeyboardButtonColor.POSITIVE)
    else:
        keyboard.add(Text("Купить билет", payload={"cmd": "noop"}), color=KeyboardButtonColor.NEGATIVE)

    keyboard.add(Text("Мои билеты", payload={"cmd": "lottery_my_tickets"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "back_to_city_menu"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_lottery_result_keyboard() -> str:
    """Клавиатура после покупки билета."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🔙 В лотерею", payload={"cmd": "lottery_main"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()