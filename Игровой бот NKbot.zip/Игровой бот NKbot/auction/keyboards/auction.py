# auction/keyboards/auction.py
# Клавиатуры для аукциона бизнесов.

from vkbottle import Keyboard, KeyboardButtonColor, Text


def get_auction_list_keyboard(businesses: list) -> str:
    """Клавиатура списка аукционных бизнесов с кнопкой перехода к ставке."""
    keyboard = Keyboard(one_time=False, inline=True)
    for biz in businesses:
        label = f"{biz['name']} | {biz['status_text']}"
        # Если бизнес находится на аукционе (is_on_auction=1) и нет владельца, можно сделать ставку
        if biz["is_on_auction"] and biz["owner_id"] is None:
            current_bid = biz["current_bid_amount"] or (2000000 if biz["type"] == "auction_casino" else 500000)
            label += f" | Текущая ставка: {current_bid} NK"
            keyboard.add(Text(label, payload={"cmd": "auction_info", "business_id": biz["business_id"]}), color=KeyboardButtonColor.PRIMARY)
        else:
            # Если бизнес не на аукционе (есть владелец или просто свободен), просто показать инфо без ставки
            keyboard.add(Text(label, payload={"cmd": "noop"}), color=KeyboardButtonColor.SECONDARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "shop_businesses"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_auction_info_keyboard(business_id: str) -> str:
    """Клавиатура с кнопкой сделать ставку."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("💰 Сделать ставку", payload={"cmd": "auction_bid", "business_id": business_id}), color=KeyboardButtonColor.POSITIVE)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "auction_list"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()