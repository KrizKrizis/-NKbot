# player/handlers/main_menu.py
# Регистрация, вводная цепочка и главное меню.

import logging
from vkbottle.bot import Blueprint, Message
from db.database import db
from utils.permissions import get_admin_info
from player.handlers.profile import format_profile
from player.keyboards.main_menu import (
    get_registration_keyboard,
    get_main_menu_keyboard,
)
from admin.base import show_admin_panel
from city.handlers.cities import show_city_menu
from bank.handlers.bank import show_bank_menu
from jobs.menu import show_categories

logger = logging.getLogger(__name__)

bp = Blueprint("player_main_menu")


async def get_or_create_user(user_id: int, first_name: str = "", last_name: str = ""):
    """
    Возвращает данные пользователя. Если пользователя нет, создаёт нового.
    Начисляет стартовые бонусы.
    """
    user = await db.fetchone("SELECT * FROM users WHERE vk_id = ?", user_id)
    if user:
        return user

    max_game_id_row = await db.fetchone("SELECT MAX(game_id) FROM users")
    max_game_id = max_game_id_row[0] if max_game_id_row and max_game_id_row[0] is not None else 5
    new_game_id = max(max_game_id + 1, 6)

    balance = 10_000
    exp = 4
    city = "Величие"
    reputation = 0

    await db.execute(
        """
        INSERT INTO users (
            vk_id, game_id, first_name, last_name,
            balance, exp, current_city, reputation, registration_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        """,
        user_id, new_game_id, first_name, last_name, balance, exp, city, reputation
    )

    await db.execute(
        "INSERT OR IGNORE INTO user_settings (user_id, receive_notifications) VALUES (?, 1)",
        user_id
    )

    logger.info(f"Зарегистрирован новый игрок: vk_id={user_id}, game_id={new_game_id}")
    return await db.fetchone("SELECT * FROM users WHERE vk_id = ?", user_id)


async def send_intro_step1(message: Message):
    """Шаг 1: Приветствие."""
    user_info = await bp.api.users.get(message.from_id)
    first_name = user_info[0].first_name if user_info else "Игрок"
    text = f"🚀 Добро пожаловать в NiksKriz Corporation, {first_name}!"
    await message.answer(text, keyboard=get_registration_keyboard("first"))


async def send_intro_step2(message: Message):
    """Шаг 2: Приветствие от мэра."""
    user = await db.fetchone("SELECT game_id FROM users WHERE vk_id = ?", message.from_id)
    game_id = user["game_id"] if user else 6
    pioneer_count = ""
    if 6 <= game_id <= 105:
        pioneer_number = game_id - 5
        pioneer_count = f"(👥 Первопроходцы: {pioneer_number}/100)"
    text = (
        "🎉 Ты новый гражданин страны NiksKriz Corporation!\n"
        f"В честь твоего прибытия {pioneer_count} мэр города Величие дарит тебе 10 000 NK и 4 опыта.\n"
        "⭐ Репутация: 0"
    )
    await message.answer(text, keyboard=get_registration_keyboard("second"))


async def send_intro_step3(message: Message):
    """Шаг 3: Советы новичку."""
    text = (
        "📌 Несколько советов перед стартом:\n\n"
        "1️⃣ Выбери банк. Это решение не окончательное, позже его можно изменить, но начать стоит с выбора подходящего банка.\n"
        "2️⃣ Отправляйся на работу. Без денег не будет ни квартиры, ни транспорта, ни бизнеса.\n"
        "3️⃣ По секрету: если захочешь вложить средства — ищи инвестиции. Но лучше заниматься этим, когда у тебя будет действительно много денег."
    )
    await message.answer(text, keyboard=get_registration_keyboard("third"))


async def show_main_menu(message: Message, edit: bool = False):
    """Показывает профиль и главное меню."""
    user = await db.fetchone("SELECT * FROM users WHERE vk_id = ?", message.from_id)
    if not user:
        return

    admin_info = await get_admin_info(message.from_id)
    admin_category = admin_info["category"] if admin_info else None

    profile_text = await format_profile(user)
    keyboard = get_main_menu_keyboard(admin_category)

    if edit:
        await message.edit(profile_text, keyboard=keyboard)
    else:
        await message.answer(profile_text, keyboard=keyboard)


@bp.on.message(text=["/start", "Начать", "начать"])
async def start_handler(message: Message):
    user = await db.fetchone("SELECT vk_id FROM users WHERE vk_id = ?", message.from_id)
    if user:
        await show_main_menu(message)
    else:
        user_info = await bp.api.users.get(message.from_id)
        first_name = user_info[0].first_name if user_info else ""
        last_name = user_info[0].last_name if user_info else ""
        await get_or_create_user(message.from_id, first_name, last_name)
        await send_intro_step1(message)


@bp.on.message(payload={"cmd": "intro_next_1"})
async def intro_step1(message: Message):
    await send_intro_step2(message)


@bp.on.message(payload={"cmd": "intro_next_2"})
async def intro_step2(message: Message):
    await send_intro_step3(message)


@bp.on.message(payload={"cmd": "intro_finish"})
async def intro_finish(message: Message):
    await show_main_menu(message, edit=True)


@bp.on.message(payload={"cmd": "refresh_profile"})
async def refresh_profile(message: Message):
    await show_main_menu(message, edit=True)


@bp.on.message(payload={"cmd": "back_to_main"})
async def back_to_main(message: Message):
    await show_main_menu(message, edit=True)


@bp.on.message(payload={"cmd": "open_city"})
async def open_city(message: Message):
    await show_city_menu(message)


@bp.on.message(payload={"cmd": "open_bank"})
async def open_bank(message: Message):
    await show_bank_menu(message)


@bp.on.message(payload={"cmd": "open_jobs"})
async def open_jobs(message: Message):
    await show_categories(message)


@bp.on.message(payload={"cmd": "open_admin_panel"})
async def open_admin_panel(message: Message):
    await show_admin_panel(message)