# player/handlers/inventory.py
# Просмотр инвентаря.

from vkbottle.bot import Blueprint, Message
from db.database import db
from player.keyboards.inventory import get_inventory_keyboard

bp = Blueprint("player_inventory")


async def show_inventory_menu(message: Message):
    """Показывает содержимое инвентаря игрока."""
    items = await db.fetchall(
        """
        SELECT i.name, inv.quantity, i.type, i.base_price
        FROM inventory inv
        JOIN items i ON inv.item_id = i.item_id
        WHERE inv.user_id = ?
        ORDER BY i.type, i.name
        """,
        message.from_id
    )
    if not items:
        await message.answer("🎒 Ваш инвентарь пуст.", keyboard=get_inventory_keyboard())
        return

    lines = ["🎒 Инвентарь:"]
    for item in items:
        lines.append(f"• {item['name']} — {item['quantity']} шт.")
    text = "\n".join(lines)
    await message.answer(text, keyboard=get_inventory_keyboard())


@bp.on.message(payload={"cmd": "open_inventory"})
async def open_inventory(message: Message):
    await show_inventory_menu(message)