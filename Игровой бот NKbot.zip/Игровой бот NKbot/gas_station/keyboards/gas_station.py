# gas_station/keyboards/gas_station.py
# Клавиатуры для заправки.

from vkbottle import Keyboard, KeyboardButtonColor, Text


def get_gas_station_main_keyboard() -> str:
    """Главное меню заправки."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("Заправить 10 литров", payload={"cmd": "gas_refuel_10"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("Заправить полный бак", payload={"cmd": "gas_refuel_full"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "back_to_city_menu"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_gas_station_back_keyboard() -> str:
    """Клавиатура возврата в меню заправки."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🔙 Назад", payload={"cmd": "gas_main"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()