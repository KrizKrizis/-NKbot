# business/keyboards/business.py
# Клавиатуры для управления бизнесами и менеджерами (полный файл с добавленной get_candidates_keyboard).

from vkbottle import Keyboard, KeyboardButtonColor, Text
from db.database import db


def get_business_main_keyboard() -> str:
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("📋 Мои бизнесы", payload={"cmd": "business_my"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "back_to_more_menu"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_my_businesses_keyboard(businesses: list) -> str:
    keyboard = Keyboard(one_time=False, inline=True)
    for biz in businesses:
        keyboard.add(Text(biz["name"], payload={"cmd": "business_panel", "business_id": biz["business_id"]}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "business_main"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_business_panel_keyboard(business_id: str, is_on_auction: bool, special_income_type: str = "none", commission_rate: float = 0.0) -> str:
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("💰 Снять доход", payload={"cmd": "business_withdraw", "business_id": business_id}), color=KeyboardButtonColor.POSITIVE)
    keyboard.add(Text("🧾 Оплатить налог", payload={"cmd": "business_pay_tax", "business_id": business_id}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("📦 Оплатить продукты", payload={"cmd": "business_pay_products", "business_id": business_id}), color=KeyboardButtonColor.PRIMARY)

    if special_income_type == "bank_commission":
        keyboard.add(Text(f"Комиссия: {commission_rate:.0%}", payload={"cmd": "noop"}), color=KeyboardButtonColor.SECONDARY)
        keyboard.add(Text("Настроить комиссию", payload={"cmd": "business_set_commission", "business_id": business_id}), color=KeyboardButtonColor.PRIMARY)
    elif special_income_type == "casino_share":
        keyboard.add(Text("📊 Статистика казино", payload={"cmd": "business_casino_stats", "business_id": business_id}), color=KeyboardButtonColor.PRIMARY)
    elif special_income_type == "auto_sale_percent":
        keyboard.add(Text("📊 Продажи авто", payload={"cmd": "business_auto_stats", "business_id": business_id}), color=KeyboardButtonColor.PRIMARY)
    elif special_income_type == "estate_sale_percent":
        keyboard.add(Text("📊 Продажи жилья", payload={"cmd": "business_estate_stats", "business_id": business_id}), color=KeyboardButtonColor.PRIMARY)
    elif special_income_type == "manager_firm":
        keyboard.add(Text("👥 Менеджеры", payload={"cmd": "business_managers", "business_id": business_id}), color=KeyboardButtonColor.PRIMARY)

    if not is_on_auction:
        keyboard.add(Text("📤 Выставить на аукцион", payload={"cmd": "business_list_auction", "business_id": business_id}), color=KeyboardButtonColor.PRIMARY)
    else:
        keyboard.add(Text("📥 Снять с аукциона", payload={"cmd": "business_remove_auction", "business_id": business_id}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("💵 Продать государству", payload={"cmd": "business_sell_state", "business_id": business_id}), color=KeyboardButtonColor.NEGATIVE)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "business_my"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_bank_commission_keyboard() -> str:
    keyboard = Keyboard(one_time=False, inline=True)
    for rate in [0, 1, 2, 3, 4, 5]:
        keyboard.add(Text(f"{rate}%", payload={"cmd": "business_bank_set_commission_value", "rate": rate}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "business_panel"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_managers_keyboard(business_id: str) -> str:
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("Список менеджеров", payload={"cmd": "business_managers_list", "business_id": business_id}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("Нанять игрока", payload={"cmd": "business_hire_manager", "business_id": business_id}), color=KeyboardButtonColor.POSITIVE)
    keyboard.add(Text("Выплатить зарплату", payload={"cmd": "business_pay_all_salaries", "business_id": business_id}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("Репутация менеджеров", payload={"cmd": "business_managers_reputation", "business_id": business_id}), color=KeyboardButtonColor.PRIMARY)
    if business_id == "1.4.15":
        keyboard.add(Text("Выборы директора", payload={"cmd": "business_elect_director"}), color=KeyboardButtonColor.PRIMARY)
        keyboard.add(Text("Голосовать", payload={"cmd": "business_vote_director"}), color=KeyboardButtonColor.POSITIVE)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "business_panel", "business_id": business_id}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_managers_list_keyboard(managers: list) -> str:
    keyboard = Keyboard(one_time=False, inline=True)
    for m in managers:
        label = f"{m['first_name']} {m['last_name']} (ЗП: {m['salary']})"
        keyboard.add(Text(label, payload={"cmd": "business_manager_fire", "manager_id": m["id"]}), color=KeyboardButtonColor.PRIMARY)
        keyboard.add(Text("Пожаловаться", payload={"cmd": "business_complaint_manager", "manager_id": m["id"]}), color=KeyboardButtonColor.NEGATIVE)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "business_managers"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_managers_reputation_keyboard(managers_reputation: list) -> str:
    keyboard = Keyboard(one_time=False, inline=True)
    for r in managers_reputation:
        label = f"ID:{r['user_id']} | Репутация: {r['reputation']} | Репутация начальника: {r['boss_reputation']}"
        keyboard.add(Text(label, payload={"cmd": "noop"}), color=KeyboardButtonColor.SECONDARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "business_managers"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_complaint_reason_keyboard() -> str:
    keyboard = Keyboard(one_time=False, inline=True)
    reasons = ["Несправедливость", "Невыплата зарплаты", "Оскорбление", "Другое"]
    for reason in reasons:
        keyboard.add(Text(reason, payload={"cmd": "business_complaint_reason", "reason": reason}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Отмена", payload={"cmd": "business_managers"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


async def get_candidates_keyboard(candidates: list) -> str:
    """Клавиатура со списком кандидатов для голосования."""
    keyboard = Keyboard(one_time=False, inline=True)
    for candidate_id in candidates:
        user = await db.fetchone("SELECT first_name, last_name FROM users WHERE vk_id = ?", candidate_id)
        name = f"{user['first_name']} {user['last_name']}".strip() if user else str(candidate_id)
        keyboard.add(Text(name, payload={"cmd": "business_vote_candidate", "candidate_id": candidate_id}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "business_managers"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_back_to_business_keyboard() -> str:
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🔙 К бизнесам", payload={"cmd": "business_main"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()