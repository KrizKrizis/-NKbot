# middlewares/input_dispatcher.py
# Middleware для обработки текстовых сообщений.
# Если у пользователя есть активное FSM-состояние, сообщение пропускается
# к соответствующему обработчику. В остальных случаях сообщение также
# пропускается дальше, чтобы его мог обработать общий или модульный обработчик.

import logging
from vkbottle import BaseMiddleware
from vkbottle.bot import Message
from db.database import db

logger = logging.getLogger(__name__)


class InputDispatcher(BaseMiddleware):
    async def pre(self, message: Message, *args, **kwargs):
        # Проверяем, есть ли у пользователя активное FSM-состояние
        state_row = await db.fetchone(
            "SELECT state FROM user_states WHERE user_id = ?",
            message.from_id
        )

        # Если состояние есть, пропускаем сообщение дальше (его обработает нужный модуль)
        if state_row:
            return message

        # Все остальные сообщения также пропускаем дальше
        # чтобы их могли обработать общие обработчики (например, /start)
        return message
