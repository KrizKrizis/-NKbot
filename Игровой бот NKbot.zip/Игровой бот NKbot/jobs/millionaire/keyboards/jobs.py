# jobs/millionaire/keyboards/jobs.py
# Клавиатуры для работ категории "Миллионер".

from vkbottle import Keyboard, KeyboardButtonColor, Text


def get_millionaire_jobs_keyboard(jobs: list) -> str:
    """Клавиатура со списком доступных работ миллионера."""
    keyboard = Keyboard(one_time=False, inline=True)

    for job in jobs:
        keyboard.add(
            Text(job["name"], payload={"cmd": "millionaire_job_info", "job_id": job["job_id"]}),
            color=KeyboardButtonColor.PRIMARY
        )

    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "jobs_category_back", "category": "millionaire"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_job_info_keyboard(job_id: str) -> str:
    """Клавиатура с действиями для конкретной работы."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(
        Text("▶️ Начать", payload={"cmd": "start_work_millionaire", "job_id": job_id}),
        color=KeyboardButtonColor.POSITIVE
    )
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "jobs_category_back", "category": "millionaire"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_active_work_keyboard() -> str:
    """Клавиатура, показываемая во время активной работы."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🔄 Обновить", payload={"cmd": "refresh_work_millionaire"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("❌ Отменить", payload={"cmd": "cancel_work_millionaire"}), color=KeyboardButtonColor.NEGATIVE)
    return keyboard.get_json()