# jobs/novice/keyboards/jobs.py
# Клавиатуры для начальных работ.

from vkbottle import Keyboard, KeyboardButtonColor, Text


def get_novice_jobs_keyboard(available_job_ids: list) -> str:
    """Клавиатура со списком доступных начальных работ."""
    keyboard = Keyboard(one_time=False, inline=True)

    job_names = {
        "novice_1": "🏭 Завод",
        "novice_2": "🌾 Ферма",
        "novice_3": "⛏ Шахта",
        "novice_4": "🧱 Каменщик",
    }

    for job_id in available_job_ids:
        keyboard.add(
            Text(job_names.get(job_id, job_id), payload={"cmd": "novice_job_info", "job_id": job_id}),
            color=KeyboardButtonColor.PRIMARY
        )

    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "jobs_category_back", "category": "novice"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_job_info_keyboard(job_id: str) -> str:
    """Клавиатура с действиями для конкретной работы."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(
        Text("▶️ Начать", payload={"cmd": "start_work_novice", "job_id": job_id}),
        color=KeyboardButtonColor.POSITIVE
    )
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "jobs_category_back", "category": "novice"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_active_work_keyboard() -> str:
    """Клавиатура, показываемая во время активной работы."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🔄 Обновить", payload={"cmd": "refresh_work_novice"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("❌ Отменить", payload={"cmd": "cancel_work_novice"}), color=KeyboardButtonColor.NEGATIVE)
    return keyboard.get_json()