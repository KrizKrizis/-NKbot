# jobs/novice/handlers/jobs.py
# Обработчики начальных работ.

import logging
from datetime import datetime, timezone
from vkbottle.bot import Blueprint, Message
from db.database import db
from services.work_service import start_work, finish_work, get_job_info
from utils.formatting import format_duration
from jobs.novice.keyboards.jobs import (
    get_novice_jobs_keyboard,
    get_job_info_keyboard,
    get_active_work_keyboard,
)

logger = logging.getLogger(__name__)

bp = Blueprint("novice_jobs")

# Соответствие job_id -> business_id для блокировки
JOB_TO_BUSINESS = {
    "novice_1": "1.4.1",  # Завод
    "novice_2": "1.4.2",  # Ферма
    "novice_3": "1.4.3",  # Шахта
    "novice_4": "1.4.4",  # Каменоломня
}


async def is_business_owned_by_user(user_id: int, business_id: str) -> bool:
    """Проверяет, владеет ли игрок указанным аукционным бизнесом."""
    row = await db.fetchone(
        "SELECT id FROM businesses WHERE business_id = ? AND owner_id = ?",
        business_id, user_id
    )
    return row is not None


async def get_available_novice_jobs(user_id: int) -> list:
    """Возвращает список идентификаторов начальных работ, доступных игроку (с учётом блокировок)."""
    all_novice = ["novice_1", "novice_2", "novice_3", "novice_4"]
    available = []
    for job_id in all_novice:
        business_id = JOB_TO_BUSINESS.get(job_id)
        if business_id:
            if await is_business_owned_by_user(user_id, business_id):
                continue
        available.append(job_id)
    return available


async def show_novice_jobs(message: Message):
    """Показывает список доступных начальных работ."""
    user_id = message.from_id

    active = await db.fetchone("SELECT current_work FROM users WHERE vk_id = ?", user_id)
    if active and active["current_work"]:
        await show_active_work(message)
        return

    available_jobs = await get_available_novice_jobs(user_id)
    if not available_jobs:
        await message.answer("Нет доступных начальных работ.")
        return

    await message.answer("Начальные работы:", keyboard=get_novice_jobs_keyboard(available_jobs))


@bp.on.message(payload={"cmd": "novice_job_info"})
async def novice_job_info(message: Message):
    payload = message.get_payload_json()
    job_id = payload.get("job_id")
    job = await get_job_info(job_id)
    if not job:
        return

    duration_text = format_duration(job["duration_minutes"])
    text = f"{job['name']}\nДлительность: {duration_text}"

    await message.answer(text, keyboard=get_job_info_keyboard(job_id))


@bp.on.message(payload={"cmd": "start_work_novice"})
async def start_work_novice(message: Message):
    payload = message.get_payload_json()
    job_id = payload.get("job_id")

    business_id = JOB_TO_BUSINESS.get(job_id)
    if business_id and await is_business_owned_by_user(message.from_id, business_id):
        await message.answer("Вы не можете выполнять эту работу, так как владеете соответствующим бизнесом.")
        await show_novice_jobs(message)
        return

    success, msg = await start_work(message.from_id, job_id)
    if not success:
        await show_novice_jobs(message)
        return

    await show_active_work(message)


async def show_active_work(message: Message):
    """Показывает экран с активной работой и таймером."""
    user = await db.fetchone(
        "SELECT current_work, work_start_time, work_end_time FROM users WHERE vk_id = ?",
        message.from_id
    )
    if not user or not user["current_work"]:
        return

    job_id = user["current_work"]
    job = await get_job_info(job_id)
    end_time = datetime.fromisoformat(user["work_end_time"])
    now = datetime.now(timezone.utc)
    remaining = end_time - now
    if remaining.total_seconds() < 0:
        success, msg = await finish_work(message.from_id)
        await message.answer(msg)
        await show_novice_jobs(message)
        return

    total_seconds = int(remaining.total_seconds())
    hours, rem = divmod(total_seconds, 3600)
    minutes, seconds = divmod(rem, 60)
    time_left = f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    duration_text = format_duration(job["duration_minutes"])
    text = f"Работа: {job['name']}\nОсталось: {time_left}\nДлительность: {duration_text}"

    await message.answer(text, keyboard=get_active_work_keyboard())


@bp.on.message(payload={"cmd": "refresh_work_novice"})
async def refresh_work_novice(message: Message):
    await show_active_work(message)


@bp.on.message(payload={"cmd": "cancel_work_novice"})
async def cancel_work_novice(message: Message):
    await db.execute(
        """
        UPDATE users
        SET current_work = NULL, work_start_time = NULL, work_end_time = NULL,
            work_reward = NULL, work_drop_data = NULL
        WHERE vk_id = ?
        """,
        message.from_id
    )
    await message.answer("Работа отменена.")
    await show_novice_jobs(message)


@bp.on.message(payload={"cmd": "jobs_category_back"})
async def jobs_category_back(message: Message):
    payload = message.get_payload_json()
    category = payload.get("category")
    if category == "novice":
        await show_novice_jobs(message)
    else:
        from jobs.menu import show_categories
        await show_categories(message)