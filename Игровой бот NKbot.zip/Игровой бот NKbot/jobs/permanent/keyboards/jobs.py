# jobs/permanent/keyboards/jobs.py
# Клавиатуры для работ категории "Постоянные".

from vkbottle import Keyboard, KeyboardButtonColor, Text


def get_permanent_jobs_keyboard(jobs: list) -> str:
    """Клавиатура со списком доступных постоянных работ."""
    keyboard = Keyboard(one_time=False, inline=True)

    for job in jobs:
        keyboard.add(
            Text(job["name"], payload={"cmd": "permanent_job_info", "job_id": job["job_id"]}),
            color=KeyboardButtonColor.PRIMARY
        )

    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "jobs_category_back", "category": "permanent"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_job_info_keyboard(job_id: str) -> str:
    """Клавиатура с действиями для конкретной работы."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(
        Text("▶️ Начать", payload={"cmd": "start_work_permanent", "job_id": job_id}),
        color=KeyboardButtonColor.POSITIVE
    )
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "jobs_category_back", "category": "permanent"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_active_work_keyboard() -> str:
    """Клавиатура, показываемая во время активной работы."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🔄 Обновить", payload={"cmd": "refresh_work_permanent"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("❌ Отменить", payload={"cmd": "cancel_work_permanent"}), color=KeyboardButtonColor.NEGATIVE)
    return keyboard.get_json()