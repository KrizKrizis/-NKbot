# jobs/elite/keyboards/jobs.py
# Клавиатуры для элитной работы.

from vkbottle import Keyboard, KeyboardButtonColor, Text


def get_elite_jobs_keyboard() -> str:
    """Клавиатура со списком элитных работ (сейчас только Марс)."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(
        Text("🚀 Работа на Марсе", payload={"cmd": "elite_job_info", "job_id": "elite_1"}),
        color=KeyboardButtonColor.PRIMARY
    )
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "jobs_category_back", "category": "elite"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_job_info_keyboard(job_id: str) -> str:
    """Клавиатура с действиями для конкретной работы."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(
        Text("▶️ Начать", payload={"cmd": "start_work", "job_id": job_id}),
        color=KeyboardButtonColor.POSITIVE
    )
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "jobs_category_back", "category": "elite"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_active_work_keyboard() -> str:
    """Клавиатура, показываемая во время активной работы."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🔄 Обновить", payload={"cmd": "refresh_work"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("❌ Отменить", payload={"cmd": "cancel_work"}), color=KeyboardButtonColor.NEGATIVE)
    return keyboard.get_json()