# jobs/elite/handlers/jobs.py
# Обработчики элитной работы (Работа на Марсе).

import logging
from datetime import datetime, timezone
from vkbottle.bot import Blueprint, Message
from db.database import db
from services.work_service import start_work, finish_work, get_job_info
from jobs.elite.keyboards.jobs import (
    get_elite_jobs_keyboard,
    get_job_info_keyboard,
    get_active_work_keyboard,
)

logger = logging.getLogger(__name__)

bp = Blueprint("elite_jobs")


async def show_elite_jobs(message: Message):
    """Показывает список элитных работ (только если есть активная работа — показывает её)."""
    user_id = message.from_id

    active = await db.fetchone("SELECT current_work FROM users WHERE vk_id = ?", user_id)
    if active and active["current_work"]:
        await show_active_work(message)
        return

    await message.answer("Элитные работы:", keyboard=get_elite_jobs_keyboard())


@bp.on.message(payload={"cmd": "elite_job_info"})
async def elite_job_info(message: Message):
    payload = message.get_payload_json()
    job_id = payload.get("job_id")
    job = await get_job_info(job_id)
    if not job:
        return

    duration_text = format_duration_ru(job["duration_minutes"])
    text = f"{job['name']}\nДлительность: {duration_text}"

    await message.answer(text, keyboard=get_job_info_keyboard(job_id))


@bp.on.message(payload={"cmd": "start_work"})
async def start_work_handler(message: Message):
    payload = message.get_payload_json()
    job_id = payload.get("job_id")

    success, msg = await start_work(message.from_id, job_id)
    if not success:
        await show_elite_jobs(message)
        return

    await show_active_work(message)


async def show_active_work(message: Message):
    """Показывает экран с активной работой и таймером."""
    user = await db.fetchone(
        "SELECT current_work, work_start_time, work_end_time FROM users WHERE vk_id = ?",
        message.from_id
    )
    if not user or not user["current_work"]:
        return

    job_id = user["current_work"]
    job = await get_job_info(job_id)
    end_time = datetime.fromisoformat(user["work_end_time"])
    now = datetime.now(timezone.utc)
    remaining = end_time - now
    if remaining.total_seconds() < 0:
        success, msg = await finish_work(message.from_id)
        await message.answer(msg)
        await show_elite_jobs(message)
        return

    total_seconds = int(remaining.total_seconds())
    hours, rem = divmod(total_seconds, 3600)
    minutes, seconds = divmod(rem, 60)
    time_left = f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    duration_text = format_duration_ru(job["duration_minutes"])
    text = f"Работа: {job['name']}\nОсталось: {time_left}\nДлительность: {duration_text}"

    await message.answer(text, keyboard=get_active_work_keyboard())


@bp.on.message(payload={"cmd": "refresh_work"})
async def refresh_work(message: Message):
    await show_active_work(message)


@bp.on.message(payload={"cmd": "cancel_work"})
async def cancel_work(message: Message):
    await db.execute(
        """
        UPDATE users
        SET current_work = NULL, work_start_time = NULL, work_end_time = NULL,
            work_reward = NULL, work_drop_data = NULL
        WHERE vk_id = ?
        """,
        message.from_id
    )
    await message.answer("Работа отменена.")
    await show_elite_jobs(message)


@bp.on.message(payload={"cmd": "jobs_category_back"})
async def jobs_category_back(message: Message):
    payload = message.get_payload_json()
    category = payload.get("category")
    if category == "elite":
        await show_elite_jobs(message)
    else:
        from jobs.menu import show_categories
        await show_categories(message)


def format_duration_ru(minutes: int) -> str:
    hours = minutes // 60
    mins = minutes % 60
    if hours and mins:
        return f"{hours} ч {mins} мин"
    elif hours:
        return f"{hours} ч"
    else:
        return f"{mins} мин"