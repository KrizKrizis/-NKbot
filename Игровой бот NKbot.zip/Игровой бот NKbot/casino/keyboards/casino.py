# casino/keyboards/casino.py
# Клавиатуры для казино.

from vkbottle import Keyboard, KeyboardButtonColor, Text


def get_casino_main_keyboard(is_owner: bool) -> str:
    """Главное меню казино."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("💰 Купить фишки", payload={"cmd": "casino_buy_chips"}), color=KeyboardButtonColor.POSITIVE)
    keyboard.add(Text("💸 Продать фишки", payload={"cmd": "casino_sell_chips"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("🎮 Игры", payload={"cmd": "casino_games"}), color=KeyboardButtonColor.PRIMARY)
    if is_owner:
        keyboard.add(Text("👑 Панель владельца", payload={"cmd": "casino_owner_panel"}), color=KeyboardButtonColor.NEGATIVE)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "back_to_city_menu"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_games_keyboard() -> str:
    """Меню выбора игры."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🎲 Кости", payload={"cmd": "casino_dice_start"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("🎰 Слоты", payload={"cmd": "casino_slots_start"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("🔫 Русская рулетка", payload={"cmd": "casino_roulette_start"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "casino_main"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_dice_guess_keyboard() -> str:
    """Выбор типа ставки в костях."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("Чёт", payload={"cmd": "casino_dice_guess", "guess": "чёт"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("Нечет", payload={"cmd": "casino_dice_guess", "guess": "нечет"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("Точное число (2-12)", payload={"cmd": "casino_dice_exact"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "casino_games"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_roulette_keyboard(current_pot: int) -> str:
    """Клавиатура русской рулетки."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🔫 Выстрел", payload={"cmd": "casino_roulette_shot"}), color=KeyboardButtonColor.NEGATIVE)
    if current_pot > 0:
        keyboard.add(Text(f"💰 Забрать {current_pot}", payload={"cmd": "casino_roulette_collect"}), color=KeyboardButtonColor.POSITIVE)
    keyboard.row()
    keyboard.add(Text("🔙 Выйти", payload={"cmd": "casino_games"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_back_to_casino_keyboard() -> str:
    """Клавиатура возврата в казино."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🔙 В казино", payload={"cmd": "casino_main"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()