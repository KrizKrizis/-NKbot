# db/migrations.py
# Инициализация базы данных: создание таблиц и наполнение начальными данными.

import logging
from .database import db
from .models import get_all_create_queries

logger = logging.getLogger(__name__)


async def init_db():
    """Создаёт все таблицы и вставляет начальные данные, если их нет."""
    logger.info("Инициализация базы данных...")

    for query in get_all_create_queries():
        await db.execute(query)

    await seed_data()

    logger.info("Инициализация базы данных завершена.")


async def seed_data():
    """Вставляет базовые данные (предметы, работы, бизнесы, транспорт, жильё и т.д.)."""

    # Предметы
    items_data = [
        ("4.1.1", "Камень", "Основной ресурс для крафта", "resource", 10),
        ("4.1.2", "Железо", "Металл, получаемый из камня", "resource", 50),
        ("4.1.3", "Медь", "Металл для электроники", "resource", 40),
        ("4.1.4", "Уголь", "Топливо и сырьё", "resource", 30),
        ("4.1.5", "Золото", "Драгоценный металл", "resource", 200),
        ("4.1.6", "Алмаз", "Драгоценный камень", "resource", 500),
        ("4.1.7", "Изумруд", "Драгоценный камень", "resource", 600),
        ("4.1.8", "Металл", "Промышленный металл", "resource", 20),
        ("4.1.9", "Неизвестное семечко", "Загадочное семя", "seed", 15),
        ("4.1.10", "Еда", "Продукты питания", "resource", 25),
        ("4.1.11", "Доски", "Деревянные доски", "resource", 30),
        ("4.1.12", "Дерево", "Древесина", "resource", 20),
        ("4.1.13", "Пластик", "Полимерный материал", "resource", 25),
        ("4.1.14", "Стекло", "Стеклянные изделия", "resource", 35),
        ("4.1.16", "Семена огурца", "Для посадки", "seed", 10),
        ("4.1.17", "Семена помидора", "Для посадки", "seed", 10),
        ("4.1.18", "Семена моркови", "Для посадки", "seed", 10),
        ("4.1.19", "Семена земляники", "Для посадки", "seed", 10),
        ("4.1.20", "Семена ежевики", "Для посадки", "seed", 10),
        ("4.1.21", "Семена дыни", "Для посадки", "seed", 15),
        ("4.1.22", "Семена арбуза", "Для посадки", "seed", 15),
        ("4.1.23", "Семена яблока", "Для посадки", "seed", 20),
        ("4.1.24", "Семена вишни", "Для посадки", "seed", 20),
        ("4.1.25", "Семена груши", "Для посадки", "seed", 20),
        ("4.1.26", "Семена мандарина", "Для посадки", "seed", 20),
        ("4.1.27", "Картошка (семена)", "Для посадки", "seed", 10),
        ("4.2.1", "Каркас платы", "Компонент крафта", "component", 100),
        ("4.2.2", "Каркас ангара", "Компонент крафта", "component", 150),
        ("4.2.3", "Каркас космического корабля (деревянный)", "Компонент крафта", "component", 200),
        ("4.2.4", "Каркас марсохода (деревянный)", "Компонент крафта", "component", 200),
        ("4.2.5", "Пустой баллон", "Компонент крафта", "component", 120),
        ("4.2.6", "Компьютер", "Компонент крафта", "component", 300),
        ("4.2.7", "Медные трубы", "Компонент крафта", "component", 130),
        ("4.2.8", "Резина", "Компонент крафта", "component", 110),
        ("4.2.9", "Компрессор", "Инструмент (не расходуется)", "tool", 500, 0),
        ("4.2.11", "Кислородный баллон", "Компонент крафта", "component", 250),
        ("4.3.1", "Плата", "Компонент крафта", "component", 400),
        ("4.3.2", "Металлический ангар", "Компонент крафта", "component", 500),
        ("4.3.3", "Металлический марсоход", "Компонент крафта", "component", 600),
        ("4.3.4", "Металлический космический корабль", "Компонент крафта", "component", 600),
        ("4.3.5", "Усовершенствованный металл", "Компонент крафта", "component", 450),
        ("4.3.6", "Биотопливо", "Компонент крафта", "component", 300),
        ("4.3.7", "Квантовый компьютер", "Компонент крафта", "component", 800),
        ("4.3.8", "Металлические трубы", "Компонент крафта", "component", 350),
        ("4.3.9", "Шины", "Компонент крафта", "component", 250),
        ("4.3.10", "Скафандр", "Экипировка для Марса", "equipment", 1000, 0),
        ("4.4.1", "Система управления без ИИ", "Компонент крафта", "component", 1200),
        ("4.4.3", "Улучшенный каркас космического корабля", "Компонент крафта", "component", 1500),
        ("4.4.4", "Улучшенный каркас марсохода", "Компонент крафта", "component", 1500),
        ("4.4.5", "Космическое топливо", "Топливо для корабля", "fuel", 800),
        ("4.4.6", "ИИ", "Искусственный интеллект", "component", 2000),
        ("4.4.7", "Усовершенствованные трубы", "Компонент крафта", "component", 600),
        ("4.4.8", "Усовершенствованные шины", "Компонент крафта", "component", 500),
        ("4.5.1", "Система управления с ИИ", "Компонент крафта", "component", 3000),
        ("4.5.2", "СОЖ", "Система обеспечения жизнедеятельности", "component", 2500),
        ("4.5.3", "Космический корабль", "Легендарное транспортное средство", "legendary", 100000, 0),
        ("4.5.4", "Марсоход", "Легендарное транспортное средство", "legendary", 80000, 0),
        ("4.7.1", "Видеокарта начальная", "Для криптофермы", "videocard", 50000, 0),
        ("4.7.2", "Видеокарта улучшенная", "Для криптофермы", "videocard", 200000, 0),
        ("4.8.1", "База на Марсе", "Постоянное жильё на Марсе", "legendary", 0, 0),
        ("4.9.1", "Топор", "Инструмент для вырубки деревьев (прочность 100)", "tool", 500, 0),
        ("4.1.15", "Ящик с инструментами", "Содержит случайные инструменты", "box", 300),
    ]

    for item in items_data:
        stackable = item[5] if len(item) > 5 else 1
        await db.execute(
            "INSERT OR IGNORE INTO items (item_id, name, description, type, base_price, stackable) VALUES (?, ?, ?, ?, ?, ?)",
            item[0], item[1], item[2], item[3], item[4], stackable
        )

    # Работы
    jobs_data = [
        ("novice_1", "🏭 Завод", "novice", 100, 250, 60, 1, None, None),
        ("novice_2", "🌾 Ферма", "novice", 200, 450, 60, 1, None, None),
        ("novice_3", "⛏ Шахта", "novice", 200, 350, 60, 1, None, None),
        ("novice_4", "🧱 Каменщик", "novice", 45000, 75000, 180, 1, None, None),
        ("perm_1", "🚕 Таксист", "permanent", 2500, 5000, 10, 3, None, None),
        ("perm_2", "📦 Курьер", "permanent", 2500, 25000, 10, 4, None, None),
        ("perm_3", "🚌 Водитель автобуса", "permanent", 25000, 35000, 10, 5, None, None),
        ("perm_4", "🚛 Дальнобойщик", "millionaire", 50000, 150000, 20, 10, None, None),
        ("perm_5", "🚂 Машинист", "millionaire", 60000, 100000, 25, 20, None, None),
        ("perm_6", "✈ Пилот", "millionaire", 75000, 200000, 30, 30, None, None),
        ("elite_1", "🚀 Работа на Марсе", "elite", 300000, 500000, 60, 49, "Звездограцк", "4.8.1"),
    ]

    for job in jobs_data:
        await db.execute(
            "INSERT OR IGNORE INTO jobs (job_id, name, category, base_reward_min, base_reward_max, duration_minutes, level_required, city_restriction, required_item_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            job[0], job[1], job[2], job[3], job[4], job[5], job[6], job[7], job[8]
        )
        await db.execute(
            "INSERT OR IGNORE INTO work_settings (job_id, reward_min, reward_max) VALUES (?, ?, ?)",
            job[0], job[3], job[4]
        )

    bonuses = [
        ("novice_1", "4.1.8", 0.25),
        ("novice_1", "4.1.13", 0.25),
        ("novice_1", "4.1.14", 0.25),
        ("novice_2", "4.1.9", 0.33),
        ("novice_2", "4.1.10", 0.17),
        ("novice_2", "4.1.12", 0.33),
        ("novice_2", "4.1.11", 0.17),
        ("novice_3", "4.1.1", 0.32),
        ("novice_3", "4.1.4", 0.32),
        ("novice_3", "4.1.2", 0.16),
        ("novice_3", "4.1.6", 0.07),
        ("novice_3", "4.1.5", 0.07),
        ("novice_3", "4.1.7", 0.06),
        ("novice_4", "4.1.15", 0.50),
    ]
    for bonus in bonuses:
        await db.execute(
            "INSERT OR IGNORE INTO work_bonuses (job_id, item_id, chance) VALUES (?, ?, ?)",
            bonus[0], bonus[1], bonus[2]
        )

    # Бизнесы
    businesses_data = [
        ("1.1.1", "Ларёк с хот-догами", "personal", "novice", "Величие", None, 5000, 25000, 0, 0, "none", 0.0),
        ("1.1.2", "Шаурмечная", "personal", "novice", "Мемград", None, 15000, 45000, 0, 0, "none", 0.0),
        ("1.2.1", "Фастфуд 1", "personal", "experienced", "Мемград", None, 55000, 125000, 0, 0, "none", 0.0),
        ("1.2.2", "Фастфуд 2", "personal", "experienced", "Мемград", None, 55000, 125000, 0, 0, "none", 0.0),
        ("1.3.1", "Ветряные мельницы", "personal", "millionaire", "Звездограцк", None, 75000, 225000, 22500, 0, "none", 0.0),
        ("1.3.2", "Заправка 1", "personal", "millionaire", "Величие", None, 85000, 225000, 23250, 0, "none", 0.0),
        ("1.3.3", "Заправка 2", "personal", "millionaire", "Величие", None, 85000, 225000, 23250, 0, "none", 0.0),
        ("1.3.4", "Компьютерный центр", "personal", "millionaire", "Звездограцк", None, 100000, 325000, 31875, 0, "none", 0.0),
        ("1.4.1", "Завод", "auction_standard", "standard", None, None, 450000, 750000, 150000, 100000, "work_percent", 0.0),
        ("1.4.2", "Ферма", "auction_standard", "standard", None, None, 450000, 750000, 150000, 100000, "work_percent", 0.0),
        ("1.4.3", "Шахта", "auction_standard", "standard", None, None, 450000, 750000, 150000, 100000, "work_percent", 0.0),
        ("1.4.4", "Каменоломня", "auction_standard", "standard", None, None, 450000, 750000, 150000, 100000, "work_percent", 0.0),
        ("1.4.5", "Автобус Клуб", "auction_standard", "standard", None, None, 450000, 1000000, 150000, 100000, "work_percent", 0.0),
        ("1.4.6", "Авто Клуб", "auction_standard", "standard", None, None, 450000, 1000000, 150000, 100000, "auto_sale_percent", 0.0),
        ("1.4.7", "Таксопарк", "auction_standard", "standard", None, None, 450000, 1000000, 150000, 100000, "work_percent", 0.0),
        ("1.4.8", "Курьерская Фирма", "auction_standard", "standard", None, None, 450000, 1000000, 150000, 100000, "work_percent", 0.0),
        ("1.4.9", "Zero Bank", "auction_standard", "bank", None, None, 500000, 1200000, 150000, 100000, "bank_commission", 0.0),
        ("1.4.10", "Fallen Bank", "auction_standard", "bank", None, None, 500000, 1200000, 150000, 100000, "bank_commission", 0.0),
        ("1.4.11", "Airo Клуб", "auction_standard", "standard", None, None, 500000, 1200000, 150000, 100000, "work_percent", 0.0),
        ("1.4.12", "Train Клуб", "auction_standard", "standard", None, None, 500000, 1200000, 150000, 100000, "work_percent", 0.0),
        ("1.4.13", "Казино", "auction_casino", "casino", "Мемград", None, 250000, 800000, 150000, 150000, "casino_share", 0.0),
        ("1.4.14", "Агентство недвижимости", "auction_standard", "standard", "Величие", None, 450000, 1000000, 150000, 100000, "estate_sale_percent", 0.0),
        ("1.4.15", "Фирма менеджеров", "auction_standard", "manager_firm", None, None, 500000, 1200000, 150000, 100000, "manager_firm", 0.0),
    ]

    for biz in businesses_data:
        await db.execute(
            "INSERT OR IGNORE INTO businesses (business_id, name, type, category, city, owner_id, income_min, income_max, product_cost, tax_amount, special_income_type, commission_rate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            biz[0], biz[1], biz[2], biz[3], biz[4], biz[5], biz[6], biz[7], biz[8], biz[9], biz[10], biz[11]
        )

    vehicles = [
        ("3.1.1", "ВАЗ 2107", 350000, 39, 8.0, "russia/ussr", "car"),
        ("3.1.2", "Hyundai Solaris", 1000000, 50, 7.5, "foreign", "car"),
        ("3.1.3", "Toyota Camry", 1350000, 60, 9.0, "foreign", "car"),
        ("3.2.1", "Lada Niva", 650000, 42, 11.0, "russia/ussr", "car"),
    ]
    for v in vehicles:
        await db.execute(
            "INSERT OR IGNORE INTO vehicles (vehicle_id, name, price, tank_capacity, fuel_consumption, country, type) VALUES (?, ?, ?, ?, ?, ?, ?)",
            v[0], v[1], v[2], v[3], v[4], v[5], v[6]
        )

    housing = [
        ("2.1.1", "Однокомнатная квартира", "apartment", 2000000, 1),
        ("2.1.2", "Двухкомнатная квартира", "apartment", 4000000, 2),
        ("2.1.3", "Трёхкомнатная квартира", "apartment", 8000000, 3),
        ("2.1.4", "Студия", "apartment", 10000000, 5),
        ("2.2.1", "Одноэтажный дом", "house", 16000000, 6),
        ("2.2.2", "Двухэтажный дом", "house", 30000000, 10),
    ]
    for h in housing:
        await db.execute(
            "INSERT OR IGNORE INTO housing (housing_id, name, type, price, parking_spots) VALUES (?, ?, ?, ?, ?)",
            h[0], h[1], h[2], h[3], h[4]
        )

    accounts = [
        ("emission", "Эмиссионный", 0, "Авто-доход каждые 3 часа"),
        ("commission", "Комиссионный", 0, "Плата за размещение на NKVito"),
        ("lottery", "Лотерейный", 0, "Призовой фонд лотереи"),
        ("investment", "Инвестиционный", 0, "Сбор на терраформирование Марса"),
        ("giveaways", "Розыгрышной", 0, "Призовые фонды ивентов"),
        ("salary", "Зарплатный", 0, "Выплаты команде проекта"),
    ]
    for acc in accounts:
        await db.execute(
            "INSERT OR IGNORE INTO system_accounts (account_name, balance, description) VALUES (?, ?, ?)",
            acc[0], acc[1], acc[2]
        )

    achievements = [
        ("first_step", "Первопроходец", "ID от 6 до 105", "registration"),
        ("mars_investor", "Марсианский вкладчик", "Инвестировать ровно 10 000 000 NK", "invest_10m"),
        ("space_suit", "Земля в иллюминаторе", "Скрафтить Скафандр", "craft_4.3.10"),
        ("mars_rover", "Вперёд по бездорожью!", "Скрафтить Марсоход", "craft_4.5.4"),
        ("spaceship", "Поплывём как по маслу!", "Скрафтить Космический корабль", "craft_4.5.3"),
        ("mars_work_first", "Месье, этот камень мой!", "Первый запуск работы на Марсе", "first_mars_work"),
        ("grand_investor", "Гранд-инвестор", "Вложить 10 млн и дождаться 1 млрд", "invest_and_wait"),
        ("mars_base", "Есть ли жизнь на Марсе?", "Получить Базу на Марсе", "get_mars_base"),
        ("soviet_car", "Можно, а зачем?", "Купить российское/советское авто", "buy_soviet_car"),
        ("savings_interest", "Копейка рубль бережёт", "Получить проценты по накопительному счёту", "savings_interest"),
        ("first_investment", "Первый шаг", "Первое инвестирование", "first_investment"),
        ("first_craft", "Мастер на все руки", "Скрафтить первый предмет", "first_craft"),
        ("gambler", "Лудоман", "Сделать 100 ставок в казино", "100_bets"),
        ("philanthropist", "Филантроп", "Перевести ≥1 000 000 NK за раз", "big_transfer"),
        ("lucky", "Счастливчик", "Выиграть в лотерею", "lottery_win"),
    ]
    for ach in achievements:
        await db.execute(
            "INSERT OR IGNORE INTO achievements (achievement_id, name, description, condition_type) VALUES (?, ?, ?, ?)",
            ach[0], ach[1], ach[2], ach[3]
        )

    config_data = [
        ("crypto_farm_base_cost", "150000", "Стоимость стойки криптофермы"),
        ("crypto_farm_income_hourly", "800", "Доход начальной видеокарты в крипте/час"),
        ("crypto_farm_improved_income_hourly", "1600", "Доход улучшенной видеокарты в крипте/час"),
        ("crypto_farm_videocard_break_limit", "250000", "Лимит накопленного дохода для поломки начальной карты"),
        ("crypto_farm_improved_break_limit", "500000", "Лимит для улучшенной карты"),
        ("crypto_farm_sell_price", "50000", "Цена продажи стойки"),
        ("crypto_to_nk_rate", "10", "Курс крипты к NK (1 крипто = 10 NK)"),
        ("housing_tax_apartment", "0.005", "Налог на квартиру (доля)"),
        ("housing_tax_house", "0.006", "Налог на дом (доля)"),
        ("crypto_farm_extra_tax_daily", "500", "Доп. налог на криптоферму в сутки"),
        ("garden_plot_1_cost", "500000", "Цена первого участка"),
        ("garden_plot_2_cost", "800000", "Цена второго участка"),
        ("axe_durability", "100", "Прочность топора"),
        ("tree_wood_drop_min", "2", "Мин. дерева при вырубке"),
        ("tree_wood_drop_max", "4", "Макс. дерева при вырубке"),
        ("annual_yield_min", "10", "Мин. урожай однолетних"),
        ("annual_yield_max", "50", "Макс. урожай однолетних"),
        ("tree_yield_min", "25", "Мин. урожай деревьев"),
        ("tree_yield_max", "75", "Макс. урожай деревьев"),
        ("weekly_shop_purchase_multiplier", "5", "Множитель цены при продаже магазину раз в неделю"),
        ("private_buyer_price_update_hours", "2", "Период обновления цен частников (часы)"),
        ("exchange_rate_variation_percent", "2", "Максимальное отклонение курса на бирже (%)"),
    ]
    for key, value, desc in config_data:
        await db.execute(
            "INSERT OR IGNORE INTO config (key, value, description) VALUES (?, ?, ?)",
            key, value, desc
        )

    logger.info("Начальные данные добавлены.")