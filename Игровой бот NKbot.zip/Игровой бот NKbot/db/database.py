# db/database.py
# Менеджер базы данных: выбирает бэкенд (SQLite/PostgreSQL) и предоставляет единый интерфейс.

from typing import Optional
from config import DB_TYPE, SQLITE_PATH, DATABASE_URL
from .backends.base import DatabaseBackend
from .backends.sqlite import SQLiteBackend
from .backends.postgres import PostgresBackend


class Database:
    """Единый интерфейс для работы с базой данных."""
    _instance: Optional["Database"] = None
    backend: DatabaseBackend

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    async def initialize(self):
        """Выбирает и подключает бэкенд."""
        if self._initialized:
            return
        if DB_TYPE == "sqlite":
            self.backend = SQLiteBackend(SQLITE_PATH)
        elif DB_TYPE == "postgresql":
            self.backend = PostgresBackend(DATABASE_URL)
        else:
            raise ValueError(f"Неподдерживаемый DB_TYPE: {DB_TYPE}")
        await self.backend.connect()
        self._initialized = True

    async def close(self):
        """Закрывает соединение."""
        if self._initialized:
            await self.backend.disconnect()

    # Прокси-методы для удобства
    async def execute(self, query: str, *params):
        return await self.backend.execute(query, *params)

    async def fetchone(self, query: str, *params):
        return await self.backend.fetchone(query, *params)

    async def fetchall(self, query: str, *params):
        return await self.backend.fetchall(query, *params)

    async def execute_many(self, query: str, params_list):
        return await self.backend.execute_many(query, params_list)

    async def execute_script(self, script: str):
        return await self.backend.execute_script(script)


# Глобальный экземпляр
db = Database()