# mars/keyboards/mars.py
# Клавиатуры для инвестиций.

from vkbottle import Keyboard, KeyboardButtonColor, Text


def get_investments_keyboard() -> str:
    """Главное меню инвестиций."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🚀 Инвестировать", payload={"cmd": "invest_start"}), color=KeyboardButtonColor.POSITIVE)
    keyboard.add(Text("📊 Прогресс", payload={"cmd": "invest_progress"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "back_to_city_menu"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_invest_back_keyboard() -> str:
    """Клавиатура после ввода суммы."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🔙 В инвестиции", payload={"cmd": "invest_main"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()