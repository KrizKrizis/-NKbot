# city/keyboards/cities.py
# Клавиатуры для меню города и выбора маршрута.

from vkbottle import Keyboard, KeyboardButtonColor, Text


def get_city_menu_keyboard(current_city: str, has_active_vehicle: bool) -> str:
    """Клавиатура главного меню города с кнопками в зависимости от города и наличия транспорта."""
    keyboard = Keyboard(one_time=False, inline=True)

    if current_city == "Величие":
        keyboard.add(Text("🏠 Имущество", payload={"cmd": "open_housing"}), color=KeyboardButtonColor.PRIMARY)
    elif current_city == "Звездограцк":
        keyboard.add(Text("🚀 Инвестиции", payload={"cmd": "open_investments"}), color=KeyboardButtonColor.PRIMARY)
    elif current_city == "Мемград":
        keyboard.add(Text("🎰 Казино", payload={"cmd": "open_casino"}), color=KeyboardButtonColor.PRIMARY)

    if has_active_vehicle:
        keyboard.add(Text("🚗 Транспорт", payload={"cmd": "open_transport"}), color=KeyboardButtonColor.PRIMARY)
    else:
        keyboard.add(Text("🚌 Автобус", payload={"cmd": "open_bus_routes"}), color=KeyboardButtonColor.PRIMARY)

    keyboard.row()
    keyboard.add(Text("🛒 Магазин", payload={"cmd": "open_shop"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("⛽ Заправка", payload={"cmd": "open_gas_station"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("📦 Ещё", payload={"cmd": "open_more"}), color=KeyboardButtonColor.PRIMARY)

    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "back_to_main_from_city"}), color=KeyboardButtonColor.SECONDARY)

    return keyboard.get_json()


def get_more_menu_keyboard() -> str:
    """Клавиатура раздела «Ещё»"""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🎒 Инвентарь", payload={"cmd": "open_inventory"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("🔨 Крафт", payload={"cmd": "open_craft"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("🎫 Лотерея", payload={"cmd": "open_lottery"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("🤝 NKVito", payload={"cmd": "open_nkvito"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "back_to_city_menu"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_bus_routes_keyboard(current_city: str) -> str:
    keyboard = Keyboard(one_time=False, inline=True)
    all_cities = ["Звездограцк", "Мемград", "Величие"]
    other_cities = [c for c in all_cities if c != current_city]

    for city in other_cities:
        keyboard.add(
            Text(f"🚌 {city}", payload={"cmd": "travel_bus", "city": city}),
            color=KeyboardButtonColor.PRIMARY
        )

    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "back_to_city_menu"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_travel_result_keyboard() -> str:
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🔙 В город", payload={"cmd": "back_to_city_menu"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()