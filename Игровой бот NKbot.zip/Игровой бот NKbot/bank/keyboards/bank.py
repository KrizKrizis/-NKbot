# bank/keyboards/bank.py
# Клавиатуры для банковских разделов.

from vkbottle import Keyboard, KeyboardButtonColor, Text


def get_bank_main_keyboard(has_bank: bool) -> str:
    """Главное меню банка."""
    keyboard = Keyboard(one_time=False, inline=True)
    if not has_bank:
        keyboard.add(Text("🏦 Выбрать банк", payload={"cmd": "bank_select"}), color=KeyboardButtonColor.PRIMARY)
    else:
        keyboard.add(Text("💰 Баланс", payload={"cmd": "bank_balance"}), color=KeyboardButtonColor.PRIMARY)
        keyboard.add(Text("↔️ Переводы", payload={"cmd": "bank_transfer_menu"}), color=KeyboardButtonColor.PRIMARY)
        keyboard.add(Text("📈 Накопительный", payload={"cmd": "bank_savings"}), color=KeyboardButtonColor.PRIMARY)
        keyboard.add(Text("🧾 Налоговый", payload={"cmd": "bank_tax"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "back_to_main"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_bank_selection_keyboard() -> str:
    """Клавиатура выбора банка."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("NK Bank", payload={"cmd": "bank_choose", "bank": "NK Bank"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("Zero Bank", payload={"cmd": "bank_choose", "bank": "Zero Bank"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("Fallen Bank", payload={"cmd": "bank_choose", "bank": "Fallen Bank"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "bank_main"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_balance_keyboard() -> str:
    """Клавиатура после показа баланса."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🔙 Назад", payload={"cmd": "bank_main"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_transfer_menu_keyboard() -> str:
    """Меню переводов."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("👤 Другому игроку", payload={"cmd": "bank_transfer_user"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("🔄 Между своими счетами", payload={"cmd": "bank_transfer_own"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "bank_main"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_account_selection_keyboard() -> str:
    """Клавиатура выбора счёта."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("Наличные", payload={"cmd": "bank_select_account", "account": "balance"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("Основной счёт", payload={"cmd": "bank_select_account", "account": "bank_checking"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("Накопительный", payload={"cmd": "bank_select_account", "account": "bank_savings"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("Налоговый", payload={"cmd": "bank_select_account", "account": "tax_account"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "bank_transfer_own"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_savings_keyboard() -> str:
    """Клавиатура для накопительного счёта."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🔙 Назад", payload={"cmd": "bank_main"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_tax_keyboard() -> str:
    """Клавиатура для налогового счёта."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🔙 Назад", payload={"cmd": "bank_main"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()