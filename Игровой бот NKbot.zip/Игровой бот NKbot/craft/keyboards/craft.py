# craft/keyboards/craft.py
# Клавиатуры для крафта.

from vkbottle import Keyboard, KeyboardButtonColor, Text


def get_craft_recipes_keyboard(recipes: list) -> str:
    """Клавиатура со списком доступных рецептов."""
    keyboard = Keyboard(one_time=False, inline=True)

    for recipe in recipes:
        keyboard.add(
            Text(recipe["name"], payload={"cmd": "craft_recipe_info", "recipe_id": recipe["recipe_id"]}),
            color=KeyboardButtonColor.PRIMARY
        )

    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "back_to_more_menu"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_recipe_info_keyboard(recipe_id: str) -> str:
    """Клавиатура с действиями для выбранного рецепта."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(
        Text("🔨 Скрафтить", payload={"cmd": "start_craft", "recipe_id": recipe_id}),
        color=KeyboardButtonColor.POSITIVE
    )
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "craft_recipes"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_active_craft_keyboard() -> str:
    """Клавиатура, показываемая во время активного крафта."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🔄 Обновить", payload={"cmd": "refresh_craft"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("❌ Отменить", payload={"cmd": "cancel_craft"}), color=KeyboardButtonColor.NEGATIVE)
    return keyboard.get_json()