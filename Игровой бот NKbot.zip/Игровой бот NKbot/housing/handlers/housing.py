# housing/handlers/housing.py
# Обработчики жилья.

import logging
from vkbottle.bot import Blueprint, Message
from db.database import db
from services.housing_service import (
    get_available_housing, get_user_housing, buy_housing, sell_housing,
    buy_crypto_farm, sell_crypto_farm, install_videocard, remove_videocard,
    get_garden_plots, buy_garden_plot, plant_seed, water_plant, harvest_plant,
    chop_tree, add_item_to_inventory,
)
from housing.keyboards.housing import (
    get_housing_main_keyboard, get_housing_list_keyboard, get_housing_my_keyboard,
    get_crypto_farm_keyboard, get_garden_main_keyboard, get_garden_plots_keyboard,
    get_garden_plot_actions_keyboard,
)

logger = logging.getLogger(__name__)

bp = Blueprint("housing")


async def show_housing_menu(message: Message):
    user_housing = await get_user_housing(message.from_id)
    keyboard = get_housing_main_keyboard(user_housing)
    await message.answer("🏠 Жильё", keyboard=keyboard)


@bp.on.message(payload={"cmd": "open_housing"})
async def open_housing(message: Message):
    await show_housing_menu(message)


@bp.on.message(payload={"cmd": "housing_main"})
async def housing_main(message: Message):
    await show_housing_menu(message)


@bp.on.message(payload={"cmd": "housing_buy_list"})
async def housing_buy_list(message: Message):
    housing_list = await get_available_housing()
    if not housing_list:
        await message.answer("Нет доступного жилья.")
        return
    await message.answer("Доступное жильё:", keyboard=get_housing_list_keyboard(housing_list))


@bp.on.message(payload={"cmd": "housing_buy"})
async def housing_buy(message: Message):
    payload = message.get_payload_json()
    housing_id = payload.get("housing_id")
    success, msg = await buy_housing(message.from_id, housing_id)
    await message.answer(msg)
    await show_housing_menu(message)


@bp.on.message(payload={"cmd": "housing_my"})
async def housing_my(message: Message):
    user_housing = await get_user_housing(message.from_id)
    if not user_housing:
        await message.answer("У вас нет жилья.")
        return
    text = (
        f"🏠 Ваше жильё: {user_housing['name']}\n"
        f"Тип: {user_housing['type']}\n"
        f"Парковочные места: {user_housing['parking_spots']}\n"
        f"Криптоферма: {'установлена' if user_housing['has_crypto_farm'] else 'не установлена'}"
    )
    await message.answer(text, keyboard=get_housing_my_keyboard())


@bp.on.message(payload={"cmd": "housing_sell"})
async def housing_sell(message: Message):
    success, msg = await sell_housing(message.from_id)
    await message.answer(msg)
    await show_housing_menu(message)


@bp.on.message(payload={"cmd": "housing_crypto_farm"})
async def housing_crypto_farm(message: Message):
    user_housing = await get_user_housing(message.from_id)
    if not user_housing:
        await message.answer("Сначала купите жильё.")
        return
    has_farm = user_housing["has_crypto_farm"]
    await message.answer("Криптоферма", keyboard=get_crypto_farm_keyboard(has_farm))


@bp.on.message(payload={"cmd": "housing_buy_farm"})
async def housing_buy_farm(message: Message):
    success, msg = await buy_crypto_farm(message.from_id)
    await message.answer(msg)
    await housing_crypto_farm(message)


@bp.on.message(payload={"cmd": "housing_sell_farm"})
async def housing_sell_farm(message: Message):
    success, msg = await sell_crypto_farm(message.from_id)
    await message.answer(msg)
    await housing_crypto_farm(message)


@bp.on.message(payload={"cmd": "housing_install_videocard"})
async def housing_install_videocard(message: Message):
    videocards = await db.fetchall(
        "SELECT inv.item_id, i.name FROM inventory inv JOIN items i ON inv.item_id = i.item_id WHERE inv.user_id = ? AND i.type = 'videocard'",
        message.from_id
    )
    if not videocards:
        await message.answer("У вас нет видеокарт.")
        return
    for vc in videocards:
        success, msg = await install_videocard(message.from_id, vc["item_id"])
        await message.answer(msg)
        break
    await housing_crypto_farm(message)


@bp.on.message(payload={"cmd": "housing_remove_videocard"})
async def housing_remove_videocard(message: Message):
    farm = await db.fetchone("SELECT videocard_id FROM crypto_farm WHERE user_id = ? LIMIT 1", message.from_id)
    if not farm:
        await message.answer("В ферме нет видеокарт.")
        return
    success, msg = await remove_videocard(message.from_id, farm["videocard_id"])
    await message.answer(msg)
    await housing_crypto_farm(message)


@bp.on.message(payload={"cmd": "housing_garden"})
async def housing_garden(message: Message):
    user_housing = await get_user_housing(message.from_id)
    if not user_housing or user_housing["type"] != "house":
        await message.answer("Садоводство доступно только в доме.")
        return
    plots = await get_garden_plots(message.from_id)
    if not plots:
        await message.answer("Садоводство", keyboard=get_garden_main_keyboard())
    else:
        await message.answer("Ваши участки:", keyboard=get_garden_plots_keyboard(plots))


@bp.on.message(payload={"cmd": "garden_buy_plot"})
async def garden_buy_plot(message: Message):
    payload = message.get_payload_json()
    plot_number = int(payload.get("plot"))
    success, msg = await buy_garden_plot(message.from_id, plot_number)
    await message.answer(msg)
    await housing_garden(message)


@bp.on.message(payload={"cmd": "garden_plot"})
async def garden_plot(message: Message):
    payload = message.get_payload_json()
    plot_number = int(payload.get("plot_number"))
    await message.answer(f"Участок {plot_number}", keyboard=get_garden_plot_actions_keyboard(plot_number))


# Посадка, полив, сбор, вырубка
@bp.on.message(payload={"cmd": "garden_plant"})
async def garden_plant(message: Message):
    payload = message.get_payload_json()
    plot_number = int(payload.get("plot"))
    seeds = await db.fetchall(
        "SELECT inv.item_id, i.name FROM inventory inv JOIN items i ON inv.item_id = i.item_id WHERE inv.user_id = ? AND i.type = 'seed'",
        message.from_id
    )
    if not seeds:
        await message.answer("У вас нет семян.")
        return
    from vkbottle import Keyboard, KeyboardButtonColor, Text
    kb = Keyboard(one_time=False, inline=True)
    for s in seeds:
        kb.add(Text(s["name"], payload={"cmd": "garden_select_seed", "plot": plot_number, "seed_item_id": s["item_id"]}), color=KeyboardButtonColor.PRIMARY)
    kb.row()
    kb.add(Text("🔙 Назад", payload={"cmd": "garden_plot", "plot_number": plot_number}), color=KeyboardButtonColor.SECONDARY)
    await message.answer("Выберите семя для посадки:", keyboard=kb)


@bp.on.message(payload={"cmd": "garden_select_seed"})
async def garden_select_seed(message: Message):
    payload = message.get_payload_json()
    plot_number = int(payload.get("plot"))
    seed_item_id = payload.get("seed_item_id")
    from vkbottle import Keyboard, KeyboardButtonColor, Text
    kb = Keyboard(one_time=False, inline=True)
    for slot in range(1, 26):
        kb.add(Text(str(slot), payload={"cmd": "garden_select_slot", "plot": plot_number, "seed_item_id": seed_item_id, "slot": slot}), color=KeyboardButtonColor.PRIMARY)
    kb.row()
    kb.add(Text("🔙 Назад", payload={"cmd": "garden_plot", "plot_number": plot_number}), color=KeyboardButtonColor.SECONDARY)
    await message.answer("Выберите лунку (1-25):", keyboard=kb)


@bp.on.message(payload={"cmd": "garden_select_slot"})
async def garden_select_slot(message: Message):
    payload = message.get_payload_json()
    plot_number = int(payload.get("plot"))
    slot_number = int(payload.get("slot"))
    seed_item_id = payload.get("seed_item_id")
    success, msg = await plant_seed(message.from_id, plot_number, slot_number, seed_item_id)
    await message.answer(msg)
    await garden_plot(message)


@bp.on.message(payload={"cmd": "garden_water"})
async def garden_water(message: Message):
    payload = message.get_payload_json()
    plot_number = int(payload.get("plot"))
    plants = await db.fetchall(
        "SELECT id, slot_number, plant_type FROM garden_plants WHERE user_id = ? AND plot_number = ? AND water_required_by <= datetime('now')",
        message.from_id, plot_number
    )
    if not plants:
        await message.answer("Нет растений, которые нужно полить.")
        return
    from vkbottle import Keyboard, KeyboardButtonColor, Text
    kb = Keyboard(one_time=False, inline=True)
    for p in plants:
        kb.add(Text(f"Лунка {p['slot_number']}: {p['plant_type']}", payload={"cmd": "garden_water_plant", "plant_id": p["id"]}), color=KeyboardButtonColor.PRIMARY)
    kb.row()
    kb.add(Text("🔙 Назад", payload={"cmd": "garden_plot", "plot_number": plot_number}), color=KeyboardButtonColor.SECONDARY)
    await message.answer("Какие растения полить?", keyboard=kb)


@bp.on.message(payload={"cmd": "garden_water_plant"})
async def garden_water_plant(message: Message):
    payload = message.get_payload_json()
    plant_id = int(payload.get("plant_id"))
    success, msg = await water_plant(message.from_id, plant_id)
    await message.answer(msg)
    await garden_plot(message)


@bp.on.message(payload={"cmd": "garden_harvest"})
async def garden_harvest(message: Message):
    payload = message.get_payload_json()
    plot_number = int(payload.get("plot"))
    plants = await db.fetchall(
        "SELECT id, slot_number, plant_type, can_harvest FROM garden_plants WHERE user_id = ? AND plot_number = ? AND can_harvest = 1",
        message.from_id, plot_number
    )
    if not plants:
        await message.answer("Нет растений, готовых к сбору.")
        return
    from vkbottle import Keyboard, KeyboardButtonColor, Text
    kb = Keyboard(one_time=False, inline=True)
    for p in plants:
        kb.add(Text(f"Лунка {p['slot_number']}: {p['plant_type']}", payload={"cmd": "garden_harvest_plant", "plant_id": p["id"]}), color=KeyboardButtonColor.POSITIVE)
    kb.row()
    kb.add(Text("🔙 Назад", payload={"cmd": "garden_plot", "plot_number": plot_number}), color=KeyboardButtonColor.SECONDARY)
    await message.answer("Что собрать?", keyboard=kb)


@bp.on.message(payload={"cmd": "garden_harvest_plant"})
async def garden_harvest_plant(message: Message):
    payload = message.get_payload_json()
    plant_id = int(payload.get("plant_id"))
    success, msg = await harvest_plant(message.from_id, plant_id)
    await message.answer(msg)
    await garden_plot(message)


@bp.on.message(payload={"cmd": "garden_chop_tree"})
async def garden_chop_tree(message: Message):
    payload = message.get_payload_json()
    plot_number = int(payload.get("plot"))
    trees = await db.fetchall(
        "SELECT id, slot_number, plant_type FROM garden_plants WHERE user_id = ? AND plot_number = ? AND is_tree = 1",
        message.from_id, plot_number
    )
    if not trees:
        await message.answer("Нет деревьев для вырубки.")
        return
    from vkbottle import Keyboard, KeyboardButtonColor, Text
    kb = Keyboard(one_time=False, inline=True)
    for t in trees:
        kb.add(Text(f"Лунка {t['slot_number']}: {t['plant_type']}", payload={"cmd": "garden_chop_tree_confirm", "plant_id": t["id"]}), color=KeyboardButtonColor.NEGATIVE)
    kb.row()
    kb.add(Text("🔙 Назад", payload={"cmd": "garden_plot", "plot_number": plot_number}), color=KeyboardButtonColor.SECONDARY)
    await message.answer("Какое дерево вырубить?", keyboard=kb)


@bp.on.message(payload={"cmd": "garden_chop_tree_confirm"})
async def garden_chop_tree_confirm(message: Message):
    payload = message.get_payload_json()
    plant_id = int(payload.get("plant_id"))
    success, msg = await chop_tree(message.from_id, plant_id)
    await message.answer(msg)
    await garden_plot(message)