# admin/administration/handlers/team.py
# Обработчики команды для администрации (ЗГА/ГА).

import json
import logging
from vkbottle.bot import Blueprint, Message
from vkbottle import Keyboard, KeyboardButtonColor, Text
from db.database import db
from utils.permissions import has_permission, get_admin_info
from admin.team_management import get_team_list, format_team_list, assign_role, remove_role, promote_user
from admin.administration.keyboards.team_keyboards import get_team_management_keyboard, get_role_selection_keyboard

logger = logging.getLogger(__name__)

bp = Blueprint("admin_team")


@bp.on.message(payload={"cmd": "admin_team"})
async def admin_team(message: Message):
    if not await has_permission(message.from_id, "team.view"):
        await message.answer("Недостаточно прав.")
        return
    team = await get_team_list()
    text = await format_team_list(team)
    permissions = (await get_admin_info(message.from_id))["permissions"]
    keyboard = get_team_management_keyboard(permissions)
    await message.answer(text, keyboard=keyboard)


@bp.on.message(payload={"cmd": "admin_team_assign"})
async def admin_team_assign(message: Message):
    if not await has_permission(message.from_id, "team.manage"):
        await message.answer("Недостаточно прав.")
        return
    await db.execute(
        "INSERT OR REPLACE INTO user_states (user_id, state, data) VALUES (?, 'admin_team_assign_id', '{}')",
        message.from_id
    )
    await message.answer("Введите игровой ID для назначения роли:")


@bp.on.message(payload={"cmd": "admin_team_remove"})
async def admin_team_remove(message: Message):
    if not await has_permission(message.from_id, "team.manage"):
        await message.answer("Недостаточно прав.")
        return
    await db.execute(
        "INSERT OR REPLACE INTO user_states (user_id, state, data) VALUES (?, 'admin_team_remove_id', '{}')",
        message.from_id
    )
    await message.answer("Введите игровой ID для снятия роли:")


@bp.on.message(payload={"cmd": "admin_team_promote"})
async def admin_team_promote(message: Message):
    if not await has_permission(message.from_id, "team.manage"):
        await message.answer("Недостаточно прав.")
        return
    await db.execute(
        "INSERT OR REPLACE INTO user_states (user_id, state, data) VALUES (?, 'admin_team_promote_id', '{}')",
        message.from_id
    )
    await message.answer("Введите игровой ID для повышения/понижения:")


@bp.on.message()
async def handle_admin_team_text(message: Message):
    state_row = await db.fetchone("SELECT state, data FROM user_states WHERE user_id = ?", message.from_id)
    if not state_row:
        return
    state = state_row["state"]
    text = message.text.strip()

    if state in ["admin_team_assign_id", "admin_team_remove_id", "admin_team_promote_id"]:
        if not text.isdigit():
            await message.answer("ID должен быть числом.")
            return
        game_id = int(text)
        user = await db.fetchone("SELECT vk_id FROM users WHERE game_id = ?", game_id)
        if not user:
            await message.answer("Игрок не найден.")
            await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)
            return
        target_vk_id = user["vk_id"]

        if state == "admin_team_assign_id":
            keyboard = get_role_selection_keyboard(target_vk_id, "assign")
            await message.answer("Выберите роль:", keyboard=keyboard)
            await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)
        elif state == "admin_team_remove_id":
            success, msg = await remove_role(message.from_id, target_vk_id)
            await message.answer(msg)
            await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)
            await admin_team(message)
        elif state == "admin_team_promote_id":
            keyboard = get_role_selection_keyboard(target_vk_id, "promote")
            await message.answer("Выберите новую роль:", keyboard=keyboard)
            await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)
    else:
        await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)


@bp.on.message(payload={"cmd": "admin_team_assign_confirm"})
async def admin_team_assign_confirm(message: Message):
    payload = message.get_payload_json()
    target_id = int(payload["target_id"])
    category = int(payload["category"])
    position = payload["position"]
    success, msg = await assign_role(message.from_id, target_id, category, position)
    await message.answer(msg)
    await admin_team(message)


@bp.on.message(payload={"cmd": "admin_team_promote_confirm"})
async def admin_team_promote_confirm(message: Message):
    payload = message.get_payload_json()
    target_id = int(payload["target_id"])
    category = int(payload["category"])
    position = payload["position"]
    success, msg = await promote_user(message.from_id, target_id, category, position)
    await message.answer(msg)
    await admin_team(message)