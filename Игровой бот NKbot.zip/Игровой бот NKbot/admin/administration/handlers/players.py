# admin/administration/handlers/players.py
# Обработчики управления игроками для администрации.

import json
import logging
from vkbottle.bot import Blueprint, Message
from db.database import db
from utils.permissions import get_admin_info, has_permission
from admin.player_management import (
    get_player_page, get_total_pages, get_player_profile, search_player, format_search_results,
    block_player, unblock_player, give_item, take_item, give_money, take_money,
)
from admin.administration.keyboards.players_keyboards import get_admin_players_keyboard, get_admin_player_manage_keyboard

logger = logging.getLogger(__name__)

bp = Blueprint("admin_players")


async def _get_permissions(user_id: int) -> dict:
    info = await get_admin_info(user_id)
    return info["permissions"] if info else {}


@bp.on.message(payload={"cmd": "admin_players"})
async def admin_players(message: Message):
    permissions = await _get_permissions(message.from_id)
    if not permissions.get("players.view", False):
        await message.answer("Недостаточно прав.")
        return
    page = 1
    players = await get_player_page(page)
    total_pages = await get_total_pages()
    lines = [f"Страница {page}"]
    for p in players:
        status = "🔴" if p["is_blocked"] else "🟢"
        lines.append(f"{status} {p['game_id']} | {p['first_name']} {p['last_name']} | LVL {p['level']}")
    text = "\n".join(lines)
    keyboard = get_admin_players_keyboard(page, total_pages, permissions)
    await message.answer(text, keyboard=keyboard)


@bp.on.message(payload={"cmd": "admin_players_page"})
async def admin_players_page(message: Message):
    payload = message.get_payload_json()
    page = int(payload.get("page", 1))
    permissions = await _get_permissions(message.from_id)
    players = await get_player_page(page)
    total_pages = await get_total_pages()
    lines = [f"Страница {page}"]
    for p in players:
        status = "🔴" if p["is_blocked"] else "🟢"
        lines.append(f"{status} {p['game_id']} | {p['first_name']} {p['last_name']} | LVL {p['level']}")
    text = "\n".join(lines)
    keyboard = get_admin_players_keyboard(page, total_pages, permissions)
    await message.answer(text, keyboard=keyboard)


@bp.on.message(payload={"cmd": "admin_player_stats_request"})
async def admin_player_stats_request(message: Message):
    await db.execute(
        "INSERT OR REPLACE INTO user_states (user_id, state, data) VALUES (?, 'admin_stats_id_input', '{}')",
        message.from_id
    )
    await message.answer("Введите игровой ID игрока:")


@bp.on.message(payload={"cmd": "admin_player_logs_request"})
async def admin_player_logs_request(message: Message):
    if not await has_permission(message.from_id, "players.view_extended"):
        await message.answer("Недостаточно прав.")
        return
    await db.execute(
        "INSERT OR REPLACE INTO user_states (user_id, state, data) VALUES (?, 'admin_logs_id_input', '{}')",
        message.from_id
    )
    await message.answer("Введите игровой ID игрока для просмотра логов:")


@bp.on.message(payload={"cmd": "admin_player_search_request"})
async def admin_player_search_request(message: Message):
    await db.execute(
        "INSERT OR REPLACE INTO user_states (user_id, state, data) VALUES (?, 'admin_search_input', '{}')",
        message.from_id
    )
    await message.answer("Введите имя, фамилию, @username или ID:")


@bp.on.message(payload={"cmd": "admin_player_manage_request"})
async def admin_player_manage_request(message: Message):
    permissions = await _get_permissions(message.from_id)
    if not any(permissions.get(k, False) for k in ["players.freeze", "players.target_block", "players.full_ban", "players.give_money", "players.take_money", "players.give_item", "players.take_item"]):
        await message.answer("Недостаточно прав.")
        return
    await db.execute(
        "INSERT OR REPLACE INTO user_states (user_id, state, data) VALUES (?, 'admin_manage_id_input', '{}')",
        message.from_id
    )
    await message.answer("Введите игровой ID игрока для управления:")


@bp.on.message(payload={"cmd": "admin_manage_freeze"})
async def admin_manage_freeze(message: Message):
    payload = message.get_payload_json()
    target_id = int(payload["target_id"])
    if not await has_permission(message.from_id, "players.freeze"):
        await message.answer("Недостаточно прав.")
        return
    await db.execute(
        "INSERT OR REPLACE INTO user_states (user_id, state, data) VALUES (?, 'admin_freeze_duration', ?)",
        message.from_id, json.dumps({"target_id": target_id})
    )
    await message.answer("Введите длительность заморозки в днях (0 = навсегда):")


@bp.on.message(payload={"cmd": "admin_manage_target_block"})
async def admin_manage_target_block(message: Message):
    payload = message.get_payload_json()
    target_id = int(payload["target_id"])
    if not await has_permission(message.from_id, "players.target_block"):
        await message.answer("Недостаточно прав.")
        return
    await db.execute(
        "INSERT OR REPLACE INTO user_states (user_id, state, data) VALUES (?, 'admin_target_duration', ?)",
        message.from_id, json.dumps({"target_id": target_id})
    )
    await message.answer("Введите длительность точечной блокировки в днях (0 = навсегда):")


@bp.on.message(payload={"cmd": "admin_manage_full_ban"})
async def admin_manage_full_ban(message: Message):
    payload = message.get_payload_json()
    target_id = int(payload["target_id"])
    if not await has_permission(message.from_id, "players.full_ban"):
        await message.answer("Недостаточно прав.")
        return
    success, msg = await block_player(message.from_id, target_id, "full", 0)
    await message.answer(msg)
    await admin_players(message)


@bp.on.message(payload={"cmd": "admin_manage_unblock"})
async def admin_manage_unblock(message: Message):
    payload = message.get_payload_json()
    target_id = int(payload["target_id"])
    if not await has_permission(message.from_id, "players.unblock"):
        await message.answer("Недостаточно прав.")
        return
    success, msg = await unblock_player(message.from_id, target_id)
    await message.answer(msg)
    await admin_players(message)


@bp.on.message(payload={"cmd": "admin_manage_give_money"})
async def admin_manage_give_money(message: Message):
    payload = message.get_payload_json()
    target_id = int(payload["target_id"])
    if not await has_permission(message.from_id, "players.give_money"):
        await message.answer("Недостаточно прав.")
        return
    await db.execute(
        "INSERT OR REPLACE INTO user_states (user_id, state, data) VALUES (?, 'admin_give_money_amount', ?)",
        message.from_id, json.dumps({"target_id": target_id})
    )
    await message.answer("Введите сумму для выдачи:")


@bp.on.message(payload={"cmd": "admin_manage_take_money"})
async def admin_manage_take_money(message: Message):
    payload = message.get_payload_json()
    target_id = int(payload["target_id"])
    if not await has_permission(message.from_id, "players.take_money"):
        await message.answer("Недостаточно прав.")
        return
    await db.execute(
        "INSERT OR REPLACE INTO user_states (user_id, state, data) VALUES (?, 'admin_take_money_amount', ?)",
        message.from_id, json.dumps({"target_id": target_id})
    )
    await message.answer("Введите сумму для изъятия:")


@bp.on.message(payload={"cmd": "admin_manage_give_item"})
async def admin_manage_give_item(message: Message):
    payload = message.get_payload_json()
    target_id = int(payload["target_id"])
    if not await has_permission(message.from_id, "players.give_item"):
        await message.answer("Недостаточно прав.")
        return
    await db.execute(
        "INSERT OR REPLACE INTO user_states (user_id, state, data) VALUES (?, 'admin_give_item_id', ?)",
        message.from_id, json.dumps({"target_id": target_id})
    )
    await message.answer("Введите ID предмета:")


@bp.on.message(payload={"cmd": "admin_manage_take_item"})
async def admin_manage_take_item(message: Message):
    payload = message.get_payload_json()
    target_id = int(payload["target_id"])
    if not await has_permission(message.from_id, "players.take_item"):
        await message.answer("Недостаточно прав.")
        return
    await db.execute(
        "INSERT OR REPLACE INTO user_states (user_id, state, data) VALUES (?, 'admin_take_item_id', ?)",
        message.from_id, json.dumps({"target_id": target_id})
    )
    await message.answer("Введите ID предмета:")


@bp.on.message()
async def handle_admin_players_text(message: Message):
    state_row = await db.fetchone("SELECT state, data FROM user_states WHERE user_id = ?", message.from_id)
    if not state_row:
        return
    state = state_row["state"]
    text = message.text.strip()
    data = json.loads(state_row["data"])
    target_id = data.get("target_id")

    if state == "admin_stats_id_input":
        if not text.isdigit():
            await message.answer("ID должен быть числом.")
            return
        game_id = int(text)
        user = await db.fetchone("SELECT vk_id FROM users WHERE game_id = ?", game_id)
        if not user:
            await message.answer("Игрок не найден.")
            await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)
            return
        profile = await get_player_profile(user["vk_id"], message.from_id)
        await message.answer(profile)
        await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)

    elif state == "admin_logs_id_input":
        if not text.isdigit():
            await message.answer("ID должен быть числом.")
            return
        game_id = int(text)
        user = await db.fetchone("SELECT vk_id FROM users WHERE game_id = ?", game_id)
        if not user:
            await message.answer("Игрок не найден.")
            await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)
            return
        logs = await db.fetchall("SELECT * FROM admin_log WHERE admin_id = ? ORDER BY id DESC LIMIT 20", user["vk_id"])
        lines = ["📋 Логи игрока:"]
        for l in logs:
            lines.append(f"  • {l['action']}: {l['details']} ({l['timestamp']})")
        await message.answer("\n".join(lines))
        await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)

    elif state == "admin_search_input":
        results = await search_player(text)
        await message.answer(await format_search_results(results))
        await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)

    elif state == "admin_manage_id_input":
        if not text.isdigit():
            await message.answer("ID должен быть числом.")
            return
        game_id = int(text)
        user = await db.fetchone("SELECT vk_id FROM users WHERE game_id = ?", game_id)
        if not user:
            await message.answer("Игрок не найден.")
            await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)
            return
        permissions = await _get_permissions(message.from_id)
        keyboard = get_admin_player_manage_keyboard(user["vk_id"], permissions)
        await message.answer("Выберите действие:", keyboard=keyboard)
        await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)

    elif state == "admin_freeze_duration":
        if not text.isdigit():
            await message.answer("Длительность должна быть числом.")
            return
        days = int(text)
        success, msg = await block_player(message.from_id, target_id, "freeze", days)
        await message.answer(msg)
        await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)
        await admin_players(message)

    elif state == "admin_target_duration":
        if not text.isdigit():
            await message.answer("Длительность должна быть числом.")
            return
        days = int(text)
        success, msg = await block_player(message.from_id, target_id, "target", days)
        await message.answer(msg)
        await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)
        await admin_players(message)

    elif state == "admin_give_money_amount":
        if not text.isdigit():
            await message.answer("Сумма должна быть числом.")
            return
        amount = int(text)
        success, msg = await give_money(message.from_id, target_id, amount)
        await message.answer(msg)
        await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)
        await admin_players(message)

    elif state == "admin_take_money_amount":
        if not text.isdigit():
            await message.answer("Сумма должна быть числом.")
            return
        amount = int(text)
        success, msg = await take_money(message.from_id, target_id, amount)
        await message.answer(msg)
        await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)
        await admin_players(message)

    elif state == "admin_give_item_id":
        item_id = text
        await db.execute(
            "INSERT OR REPLACE INTO user_states (user_id, state, data) VALUES (?, 'admin_give_item_qty', ?)",
            message.from_id, json.dumps({"target_id": target_id, "item_id": item_id})
        )
        await message.answer("Введите количество:")

    elif state == "admin_take_item_id":
        item_id = text
        await db.execute(
            "INSERT OR REPLACE INTO user_states (user_id, state, data) VALUES (?, 'admin_take_item_qty', ?)",
            message.from_id, json.dumps({"target_id": target_id, "item_id": item_id})
        )
        await message.answer("Введите количество:")

    elif state == "admin_give_item_qty":
        if not text.isdigit():
            await message.answer("Количество должно быть числом.")
            return
        qty = int(text)
        item_id = data.get("item_id")
        success, msg = await give_item(message.from_id, target_id, item_id, qty)
        await message.answer(msg)
        await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)
        await admin_players(message)

    elif state == "admin_take_item_qty":
        if not text.isdigit():
            await message.answer("Количество должно быть числом.")
            return
        qty = int(text)
        item_id = data.get("item_id")
        success, msg = await take_item(message.from_id, target_id, item_id, qty)
        await message.answer(msg)
        await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)
        await admin_players(message)

    else:
        await db.execute("DELETE FROM user_states WHERE user_id = ?", message.from_id)