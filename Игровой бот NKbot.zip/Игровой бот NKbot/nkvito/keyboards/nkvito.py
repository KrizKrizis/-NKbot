# nkvito/keyboards/nkvito.py
# Клавиатуры для NKVito.

from vkbottle import Keyboard, KeyboardButtonColor, Text


def get_nkvito_main_keyboard() -> str:
    """Главное меню NKVito."""
    keyboard = Keyboard(one_time=False, inline=True)
    keyboard.add(Text("🛍 Список лотов", payload={"cmd": "nkvito_listings"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.add(Text("➕ Создать лот", payload={"cmd": "nkvito_create"}), color=KeyboardButtonColor.POSITIVE)
    keyboard.add(Text("📋 Мои лоты", payload={"cmd": "nkvito_my"}), color=KeyboardButtonColor.PRIMARY)
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "back_to_more_menu"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_listings_keyboard(listings: list, page: int, has_next: bool) -> str:
    """Клавиатура списка лотов с кнопками покупки и пагинацией."""
    keyboard = Keyboard(one_time=False, inline=True)

    for lot in listings:
        label = f"{lot['item_name']} - {lot['price']} NK (Продавец: {lot['seller_game_id']})"
        keyboard.add(
            Text(label, payload={"cmd": "nkvito_buy", "listing_id": lot["id"]}),
            color=KeyboardButtonColor.PRIMARY
        )

    nav_row = []
    if page > 1:
        nav_row.append(Text("⬅️ Назад", payload={"cmd": "nkvito_page", "page": page - 1}))
    if has_next:
        nav_row.append(Text("➡️ Вперёд", payload={"cmd": "nkvito_page", "page": page + 1}))
    if nav_row:
        keyboard.row()
        for btn in nav_row:
            keyboard.add(btn, color=KeyboardButtonColor.SECONDARY)

    keyboard.row()
    keyboard.add(Text("🔙 К меню", payload={"cmd": "nkvito_menu"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_inventory_items_keyboard(items: list) -> str:
    """Клавиатура выбора предмета из инвентаря."""
    keyboard = Keyboard(one_time=False, inline=True)
    for item in items:
        label = f"{item['name']} (x{item['quantity']})"
        keyboard.add(
            Text(label, payload={"cmd": "nkvito_select_item", "item_id": item["item_id"]}),
            color=KeyboardButtonColor.PRIMARY
        )
    keyboard.row()
    keyboard.add(Text("🔙 Отмена", payload={"cmd": "nkvito_menu"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_duration_keyboard() -> str:
    """Клавиатура выбора срока размещения."""
    keyboard = Keyboard(one_time=False, inline=True)
    durations = [
        ("1 день (1500 NK)", 1),
        ("2 дня (3000 NK)", 2),
        ("3 дня (5000 NK)", 3),
        ("4 дня (7500 NK)", 4),
        ("5 дней (10000 NK)", 5),
    ]
    for label, days in durations:
        keyboard.add(
            Text(label, payload={"cmd": "nkvito_duration", "days": days}),
            color=KeyboardButtonColor.PRIMARY
        )
    keyboard.row()
    keyboard.add(Text("🔙 Отмена", payload={"cmd": "nkvito_menu"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()


def get_my_listings_keyboard(listings: list) -> str:
    """Клавиатура со своими лотами (можно отменить)."""
    keyboard = Keyboard(one_time=False, inline=True)
    for lot in listings:
        label = f"{lot['item_name']} - {lot['price']} NK"
        keyboard.add(
            Text(label, payload={"cmd": "nkvito_cancel", "listing_id": lot["id"]}),
            color=KeyboardButtonColor.PRIMARY
        )
    keyboard.row()
    keyboard.add(Text("🔙 Назад", payload={"cmd": "nkvito_menu"}), color=KeyboardButtonColor.SECONDARY)
    return keyboard.get_json()